package com.iesbelen.dam.apirest.apiactividad3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiActividad3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
