package com.dao;

import java.util.List;

public interface IDAO {
        void list();
        void update(int id);
        void insert();
        void remove(int id);
}
