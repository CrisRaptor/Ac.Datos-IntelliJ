package com.iesbelen.dam.apirest.apiactividad1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiActividad1Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiActividad1Application.class, args);
    }

}
