package com.iesbelen.dam.apirest.apiactividad2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiActividad2Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiActividad2Application.class, args);
    }

}
