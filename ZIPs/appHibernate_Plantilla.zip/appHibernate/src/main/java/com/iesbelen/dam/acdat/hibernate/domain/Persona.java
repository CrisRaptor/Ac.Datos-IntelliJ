package com.iesbelen.dam.acdat.hibernate.domain;

public class Persona {
}
