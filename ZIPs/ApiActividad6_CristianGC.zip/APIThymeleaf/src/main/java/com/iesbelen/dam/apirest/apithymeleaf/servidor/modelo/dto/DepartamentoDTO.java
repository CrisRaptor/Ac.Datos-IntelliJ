package com.iesbelen.dam.apirest.apithymeleaf.servidor.modelo.dto;

public class DepartamentoDTO {
}
