package com.iesbelen.dam.apirest.apirestfutbol2425thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestFutbol2425ThymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestFutbol2425ThymeleafApplication.class, args);
    }

}
