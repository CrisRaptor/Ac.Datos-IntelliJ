package com.iesbelen.dam.apirest.apirestfutbol2425thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestFutbol2425ThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
