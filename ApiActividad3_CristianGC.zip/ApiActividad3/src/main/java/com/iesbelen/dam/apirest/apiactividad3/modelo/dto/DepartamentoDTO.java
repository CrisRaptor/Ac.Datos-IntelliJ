package com.iesbelen.dam.apirest.apiactividad3.modelo.dto;

public class DepartamentoDTO {
}
