public class Main {
    private int miAtributo;

    public static void main(String[] args) {
    }
}