package com.iesbelen.dam.apirest.apiactividad3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiActividad3Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiActividad3Application.class, args);
    }

}
