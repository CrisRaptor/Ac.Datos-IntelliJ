package com.iesbelen.dam.apirest.springapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringApiRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringApiRestApplication.class, args);
    }

}
