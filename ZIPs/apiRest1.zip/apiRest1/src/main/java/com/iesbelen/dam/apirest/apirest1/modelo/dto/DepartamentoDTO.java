package com.iesbelen.dam.apirest.apirest1.modelo.dto;

public class DepartamentoDTO {
}
