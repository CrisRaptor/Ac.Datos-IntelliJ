package com.iesbelen.dam.apirest.apiactividad2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiActividad2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
