package com.iesbelen.dam.apirest.apirestfutbol2425thymeleaf.modelo.daos;

import com.iesbelen.dam.apirest.apirestfutbol2425thymeleaf.modelo.entidades.Equipo;
import org.springframework.data.repository.CrudRepository;

public interface IEquipoDAO extends CrudRepository<Equipo, Integer> {
}
