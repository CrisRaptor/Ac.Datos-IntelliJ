package com.iesbelen.dam.apirest.apirestfutbol2425;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestFutbol2425ApplicationTests {

    @Test
    void contextLoads() {
    }

}
