package zona_fit.datos;

public class CuotaDAO {
}
