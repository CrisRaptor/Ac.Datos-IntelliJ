package com.iesbelen.dam.apirest.springapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApiRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
