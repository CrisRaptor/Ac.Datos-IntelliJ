package com.iesbelen.dam.apirest.apirestfutbol2425;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestFutbol2425Application {

    public static void main(String[] args) {
        SpringApplication.run(ApiRestFutbol2425Application.class, args);
    }

}
