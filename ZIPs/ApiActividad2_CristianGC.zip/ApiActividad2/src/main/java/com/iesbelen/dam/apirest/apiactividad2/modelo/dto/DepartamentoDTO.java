package com.iesbelen.dam.apirest.apiactividad2.modelo.dto;

public class DepartamentoDTO {
}
